<li class="nav-item">
    <a class="nav-link " href="/horario">
        <i class="ni ni-calendar-grid-58 text-primary"></i> Gestionar horario
    </a>
</li>
<li class="nav-item">
    <a class="nav-link " href="/miscitas">
        <i class="fas fa-clock text-info"></i> Mis citas
    </a>
</li>